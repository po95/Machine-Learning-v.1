a = dict()
a['bn'] = 22
if('bn' in a):
	print(a['bn'])